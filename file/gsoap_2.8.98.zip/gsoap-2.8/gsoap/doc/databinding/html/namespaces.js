var namespaces =
[
    [ "std", "namespacestd.html", null ]
];