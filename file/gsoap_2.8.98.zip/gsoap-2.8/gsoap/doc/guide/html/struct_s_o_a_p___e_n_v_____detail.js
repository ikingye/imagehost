var struct_s_o_a_p___e_n_v_____detail =
[
    [ "__any", "struct_s_o_a_p___e_n_v_____detail.html#a261e42921673a28bd085a47d4ed65ce6", null ],
    [ "__type", "struct_s_o_a_p___e_n_v_____detail.html#ae21be5af0f3f6dc47f2dbf4e35e22300", null ],
    [ "fault", "struct_s_o_a_p___e_n_v_____detail.html#a159d344759c06f82eae1949aea10a1cf", null ]
];