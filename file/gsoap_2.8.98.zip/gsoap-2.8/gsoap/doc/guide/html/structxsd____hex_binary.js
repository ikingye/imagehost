var structxsd____hex_binary =
[
    [ "__ptr", "structxsd____hex_binary.html#adade1cbcc8c6ff25037794f38944f999", null ],
    [ "__size", "structxsd____hex_binary.html#a4c213d448af3955f37dded4f238301e6", null ],
    [ "id", "structxsd____hex_binary.html#ac5587513560c554d1a4e79c12cf539b3", null ],
    [ "options", "structxsd____hex_binary.html#ac48a47543612c0ef7d82d9c56e8ef0ea", null ],
    [ "type", "structxsd____hex_binary.html#aca3989c246550b6281ba8ee5863ac75e", null ]
];