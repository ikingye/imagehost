var struct_s_o_a_p___e_n_v_____fault =
[
    [ "detail", "struct_s_o_a_p___e_n_v_____fault.html#af49c2a1926ebf4c865ddd444960b9adb", null ],
    [ "faultactor", "struct_s_o_a_p___e_n_v_____fault.html#ae4c53ce0884ec757d48c1f62a516edce", null ],
    [ "faultcode", "struct_s_o_a_p___e_n_v_____fault.html#ad800dbd32b302cc9e096e6c311df29de", null ],
    [ "faultstring", "struct_s_o_a_p___e_n_v_____fault.html#ac08b3725c7c6b2e9c636995e82876a9a", null ],
    [ "SOAP_ENV__Code", "struct_s_o_a_p___e_n_v_____fault.html#acec1784f16ffd14a69a92b92f0ddd15f", null ],
    [ "SOAP_ENV__Detail", "struct_s_o_a_p___e_n_v_____fault.html#a560e6fd07a6b2f51cef97aa12282c870", null ],
    [ "SOAP_ENV__Node", "struct_s_o_a_p___e_n_v_____fault.html#a07e508b520e8a1e2c8ba20acf1c2ddd9", null ],
    [ "SOAP_ENV__Reason", "struct_s_o_a_p___e_n_v_____fault.html#a921e9d8c41d62f32ab6d4d39a2e71bc9", null ],
    [ "SOAP_ENV__Role", "struct_s_o_a_p___e_n_v_____fault.html#a9048c64196658de472d57fb42fae5daa", null ]
];