var structsoap__multipart =
[
    [ "iterator", "structsoap__multipart.html#ad9000ffe8f72fef89038c4773efdf575", null ],
    [ "description", "structsoap__multipart.html#ab527c6e6cce784c68a5bd9bb80845ca4", null ],
    [ "encoding", "structsoap__multipart.html#aca63e62c02acfbdee3cfc3e0f77ea54a", null ],
    [ "id", "structsoap__multipart.html#ad0bcd79b40a1bc1dc13fc343477f5564", null ],
    [ "location", "structsoap__multipart.html#af11a70ea80f3e1934d72b292e6d93910", null ],
    [ "next", "structsoap__multipart.html#a5521c92e49758ed873d0a8b2ec4b25c8", null ],
    [ "options", "structsoap__multipart.html#a61d8ba579009b3aa64f9509cacca10ef", null ],
    [ "ptr", "structsoap__multipart.html#a640f46b605042f37ae1592f77e31c52d", null ],
    [ "size", "structsoap__multipart.html#afc4b69f5e9ade6526b23681c105d5ca5", null ],
    [ "type", "structsoap__multipart.html#a495c8d20e0334be1b1345193ca2fb764", null ]
];