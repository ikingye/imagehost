var structsoap__cookie =
[
    [ "domain", "structsoap__cookie.html#a6b3d69923c76d97c76e7b4c5fec1ee80", null ],
    [ "env", "structsoap__cookie.html#aacd76b0b0d424bb89ee4240c274da227", null ],
    [ "expire", "structsoap__cookie.html#a41b95e8384a5edcdd64df1002a3162b4", null ],
    [ "maxage", "structsoap__cookie.html#ac40390fef80642e034c6b99a8ea71fae", null ],
    [ "modified", "structsoap__cookie.html#abb592791f60cb4b05859daebf1242bf4", null ],
    [ "name", "structsoap__cookie.html#ac8a458d1244b6ee7e7931da3a5782e65", null ],
    [ "next", "structsoap__cookie.html#a7ceb718a0dcbe145640e781cc8ecf7ff", null ],
    [ "path", "structsoap__cookie.html#ab4e90f5b59f0817ab85b6d770c25a5f9", null ],
    [ "secure", "structsoap__cookie.html#a7f43ecd1ff774a39db24d19fa7e5f948", null ],
    [ "session", "structsoap__cookie.html#aceb63cc1437ca17ea950f82d3f395eca", null ],
    [ "value", "structsoap__cookie.html#a3ca9ddd61d9e8b7cc9c93831215e5f09", null ],
    [ "version", "structsoap__cookie.html#a85e58ae9e1c527bd48b27562dfc360a3", null ]
];